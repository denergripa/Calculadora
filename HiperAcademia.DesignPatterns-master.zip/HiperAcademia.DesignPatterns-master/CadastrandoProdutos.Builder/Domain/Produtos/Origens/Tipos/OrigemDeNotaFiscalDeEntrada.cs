﻿namespace CadastrandoProdutos.Builder.Domain.Produtos.Origens.Tipos
{
    public class OrigemDeNotaFiscalDeEntrada : Origem
    {
        public override string Nome => "Produto originado de nota fiscal de entrada.";
    }
}