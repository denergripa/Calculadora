﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CadastroDeProdutos.Builder.Domain.Produtos.Origens
{
    public abstract class Origem
    {
        public abstract string Nome { get; }
    }
}