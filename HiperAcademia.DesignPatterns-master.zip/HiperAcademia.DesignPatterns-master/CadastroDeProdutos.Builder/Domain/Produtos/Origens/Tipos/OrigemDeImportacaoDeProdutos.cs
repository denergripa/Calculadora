﻿namespace CadastroDeProdutos.Builder.Domain.Produtos.Origens.Tipos
{
    public class OrigemDeImportacaoDeProdutos : Origem
    {
        public override string Nome => "Produto originado de importação de produtos.";
    }
}