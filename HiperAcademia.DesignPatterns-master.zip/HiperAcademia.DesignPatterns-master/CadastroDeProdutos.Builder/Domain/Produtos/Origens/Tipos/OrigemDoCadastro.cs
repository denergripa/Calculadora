﻿namespace CadastroDeProdutos.Builder.Domain.Produtos.Origens.Tipos
{
    public class OrigemDoCadastro : Origem
    {
        public override string Nome => "Produto originado da tela de cadastro.S";
    }
}